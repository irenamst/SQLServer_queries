use KidsToys

DELETE from Kids
DELETE from Toys

INSERT INTO Kids ([First Name],[Last Name],[Birth Date])
values
('Sam','Small',DATEADD(Month,- floor(rand() * 120),GetDate()))
,('Annie',null,'20180527')
,('Dave','Drei','20140325')
,('Ivan','Ivanov','20150517')
,('Brenda','Simon','20160315')
,('Samantha','Fox','20190715')
,('Diana','Ros','20160918')
,('Michael','Buble','20190410')
,('Bilbo','Baggins','20200125')
,('Rox','Mirers','20130411')
,('Frodo','Baggins','20150313')
,('Riana','Wober','20161115')
,('Marta',null,'20121230')

INSERT INTO Toys ([Kid Id],[Name],[Colour])
values
('1','car','blue')
,('1','ball','red')
,('1','doll','blue')
,('2','truck','green')
,('2','car','red')
,('2','ball','green')
,('2','doll','blue')
,('3','car','green')
,('4','doll','red')
,('4','ball','blue')
,('5','ball','green')
,('6','truck','blue')
,('6','truck','red')
,('7','car','green')
,('2','car','green')
,('1','ball','blue')
,('1','car','red')
,('8','ball',null)


