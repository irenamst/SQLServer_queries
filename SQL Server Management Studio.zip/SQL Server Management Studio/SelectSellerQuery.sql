/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [SellerId]
      ,[SellerName]
      ,[SellerAge]
      ,[SellerPhone]
      ,[SellerPassword]
  FROM [SuperMarketDataBase].[dbo].[SellerTable]