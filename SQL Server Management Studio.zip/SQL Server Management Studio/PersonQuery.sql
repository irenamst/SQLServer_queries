use Person

INSERT INTO PersonTable
VALUES (1,'Staneva','Irena','Hristo Kovachev','Sofia')