insert into Human values('Martin','Bulgaria');

insert into Human values('John','USA')

insert into Human values('Jean','France')

select * from Human;