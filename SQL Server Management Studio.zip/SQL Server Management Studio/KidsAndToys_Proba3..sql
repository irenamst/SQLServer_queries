SELECT Concat([First Name], ' ', [Last Name]) AS [Full Name] 
	, [Birth Date] 
FROM Kids
WHERE DateDiff(year,[Birth Date], cast( getdate() AS date ))=3 

SELECT Concat([First Name],' ',[Last Name]) As [Full Name]
FROM Kids
INNER JOIN Toys
ON Kids.Id = Toys.[Kid Id]
WHERE Toys.Colour='blue'

SELECT Concat([First Name],' ',[Last Name]) AS [Full Name]
FROM Kids, Toys
WHERE Toys.[Kid Id] = Kids.Id AND Toys.Colour='blue'

SELECT Concat(Kids.[First Name],' ',Kids.[Last Name]) AS [Full Name], Toys.[Colour] 
FROM Kids
INNER JOIN Toys ON Toys.[Kid Id]=Kids.Id;

SELECT Concat([First Name],' ',[Last Name]) AS [Full Name]
FROM Kids
WHERE DateDiff(year,[Birth Date],Cast( GetDate() AS date ))<5
AND EXISTS
(SELECT * FROM Toys WHERE Kids.Id=Toys.[Kid Id]); 

