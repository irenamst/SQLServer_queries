create table dbo.MyTable(
MyDecimalColumn DECIMAL(5,2)
,MyNumericColumn NUMERIC(10,5)
);
Go
INSERT INTO dbo.MyTable VALUES
(123,12345.12);
GO
SELECT MyDecimalColumn,MyNumericColumn
FROM dbo.MyTable;