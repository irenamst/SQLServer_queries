CREATE DATABASE Customer;
USE Customer;
drop table Customer
CREATE TABLE Customer
(
	Id int primary key not null identity(1,1),
	FirstName varchar(50) not null,
	LastName varchar(50) not null,
	Age int not null,
	City varchar(50) not null
);
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Joey','Blue',40,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Barry','Bonds',50,'Varna');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt',40,'Varna,Ignatievo');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt1',50,'Varna,Ignatievo');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt2',50,'Varna,Ignatievo');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt3',50,'Varna,Ignatievo');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt4',50,'Varna,Ignatievo');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt5',50,'Varna,Ignatievo');

select *
from Customer

select Id,FirstName,LastName,Age,City
from Customer

select Id,FirstName,LastName,Age,City
from Customer
where FirstName='Mike';

select Id,FirstName,LastName,Age,City
from Customer
where FirstName='Mike'
AND LastName='Schmidt';

select Id,FirstName,LastName,Age,City
from Customer
where FirstName='Mike'
AND LastName Like 'Schmidt%';

select Id,FirstName,LastName,Age,City
from Customer
where FirstName='Mike'
AND LastName Like 'Schmidt_';

select Id,FirstName,LastName,Age,City
from Customer
where FirstName = 'Joey'
AND LastName Like 'Blue';

update Customer
set Age=20
where FirstName='Joey'
and LastName = 'Blue';

select Id,FirstName,LastName,Age,City
from Customer

update Customer
set Age=35
where FirstName = 'Joey'
and LastName ='Blue';

select Id,FirstName,LastName,Age,City
from Customer

update Customer
set Age=35;

select Id,FirstName,LastName,Age,City
from Customer

DELETE Customer;

select Id,FirstName,LastName,Age,City
from Customer

INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Joey','Blue',40,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Barry','Bonds',50,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt',60,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt1',61,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt2',62,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt3',63,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt4',64,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt5',65,'Sofia');

select FirstName,LastName,Age,City
from Customer

select FirstName,LastName,Age,City
from Customer
where FirstName='Mike'
and LastName Like 'Schmidt_';

select FirstName,LastName,Age,City
from Customer

alter table customer
add Country varchar(50);

select *
from Customer

update Customer
Set Country ='Bulgaria';

select *
from Customer

update Customer
Set City ='Goddard'
where FirstName='Joey'
and LastName='Blue';

update Customer
Set Country = 'USA'
where FirstName='Joey'
and LastName='Blue';

select *
from Customer

update Customer
Set City = 'San Francisco'
where FirstName = 'Barry'
and LastName = 'Bonds';

update Customer
Set Country = 'USA'
where FirstName = 'Barry'
and LastName = 'Bonds';

select*
from Customer

DELETE Customer
where FirstName='Mike'
and LastName like 'Schmidt_';

select*
from Customer

/*alter table customer
add City varchar(50);
*/

drop table customer
CREATE TABLE Customer
(
	Id int Primary Key identity(1,1),
	FirstName varchar(50),
	LastName varchar(50),
	Age int,
	City varchar(50),
	Country varchar(50)

);


delete Customer

select * from Customer

INSERT INTO Customer
(FirstName,LastName,Age,City,Country)
values('Joey','Blue',40,'Goddard','USA');
INSERT INTO Customer
(FirstName,LastName,Age,City,Country)
values('Barry','Bonds',50,'San Francisco','USA');
INSERT INTO Customer
(FirstName,LastName,Age,City,Country)
values('Mike','Schmidt',60,'KC',null);
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Joey','Blue',40,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Barry','Bonds',50,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt',60,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt1',61,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt2',62,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt3',63,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt4',64,'Sofia');
INSERT INTO Customer
(FirstName,LastName,Age,City)
values('Mike','Schmidt5',65,'Sofia');

update Customer
Set Country ='Bulgaria'
where FirstName='Mike'
update Customer;

update Customer
set country = 'USA'
where LastName='Blue'
OR LastName='Bonds';

select * from customer

