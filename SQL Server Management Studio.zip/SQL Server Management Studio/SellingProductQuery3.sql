use SuperMarketDataBase

Delete From dbo.SellingProductTable
Insert Into dbo.SellingProductTable
Values (1,'Beef',120,60,'Meat')
Insert Into dbo.SellingProductTable
Values (2,'Milk',100,50,'Dairy')
Insert Into dbo.SellingProductTable
Values (3,'Graipfruit',130,90,'Produce')
Insert Into dbo.SellingProductTable
Values (4,'Orange Juice',150,70,'Beverage')
Insert Into dbo.SellingProductTable
Values (5,'Tomatoe',120,50,'Vegetables')