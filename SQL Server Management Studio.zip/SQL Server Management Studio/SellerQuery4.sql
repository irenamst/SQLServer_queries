Update dbo.SellerTable
set SellerName='John', SellerAge =33, SellerPhone='888 888 8888', SellerPassword='sssssss'
Where SellerId=1;