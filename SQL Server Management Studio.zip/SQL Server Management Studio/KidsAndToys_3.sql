/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Id]
      ,[Kid Id]
      ,[Name]
      ,[Colour]
  FROM [KidsToys].[dbo].[Toys]