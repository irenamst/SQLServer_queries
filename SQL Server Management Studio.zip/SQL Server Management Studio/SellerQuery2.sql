Delete From dbo.SellerTable
where SellerId=1;