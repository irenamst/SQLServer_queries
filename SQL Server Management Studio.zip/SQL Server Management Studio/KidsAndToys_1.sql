use KidsToys
drop table Kids
drop table Toys
create table Kids (
Id  Int Identity (1,1)
,[First Name] varchar(100)
,[Last Name]  varchar(100)
,[Birth Date]  datetime
)

create table Toys (
[Id]  Int Identity (1,1)
,[Kid Id]  Int
,[Name] varchar(100)
,[Colour]  varchar(100)
)