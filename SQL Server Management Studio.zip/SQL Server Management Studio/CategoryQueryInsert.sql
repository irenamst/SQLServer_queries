Insert into dbo.CategoryTable 
values (1,'beverage','all kinds of drinks')
Insert into dbo.CategoryTable
values (2,'dairy','all the dairy')