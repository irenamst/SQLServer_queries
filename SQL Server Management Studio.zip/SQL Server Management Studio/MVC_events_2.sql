use MVC;
select customer,count(dt) as transactions, SUM(amount) as total
From events
WHERE dt LIKE '2021-12%'
GROUP BY customer
Having count(dt) >=2
Order by customer
