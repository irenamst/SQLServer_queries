Update dbo.ProductTable
set ProductName='beef', ProductQuantity=50, ProductPrice=125,ProductCategory='Meat'
where ProductId=1