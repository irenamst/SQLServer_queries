Select * From ProductTable
where ProductCategory='Bevarage'