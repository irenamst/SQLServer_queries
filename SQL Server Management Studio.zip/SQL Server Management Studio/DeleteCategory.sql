Delete from dbo.CategoryTable
where [CategoryID]=1
AND [CategoryName]='beverage'
AND [CategoryDescription]='Any drink';

Delete from dbo.CategoryTable
where [CategoryID]=2
AND [CategoryName]='Dairy'
AND [CategoryDescription]='All dairies';

Delete from dbo.CategoryTable
where [CategoryID]=3
AND [CategoryName]='Meat'
AND [CategoryDescription]='Non Vegetarian';

Delete from dbo.CategoryTable
where [CategoryID]=4
AND [CategoryName]='Produce'
AND [CategoryDescription]='Vegetarian';

Delete from dbo.CategoryTable
where [CategoryID]=5
AND [CategoryName]='cleaning'
AND [CategoryDescription]='Cleaning products';

select * from dbo.CategoryTable;

insert into CategoryTable
values(1,'beverage','Any drink');

insert into CategoryTable
values(2,'Dairy','Several dairies');

insert into CategoryTable
values(3,'Meat','Non Vegetarian');

insert into CategoryTable
values(4,'Produce','Vegetarian');

insert into CategoryTable
values(5,'cleaning','Cleaning products');

select * from dbo.CategoryTable;

update CategoryTable 
set CategoryName='Beverage', CategoryDescription='Any Drink' 
where CategoryID=1;

update CategoryTable
set CategoryName='Dairy', CategoryDescription='All Dairies'
where CategoryID=2;

update CategoryTable
set CategoryName='Meat', CategoryDescription='Any Kind of Meat'
where CategoryID=3;

update CategoryTable
set CategoryName='Produce', CategoryDescription='All Fruits And Vegetables'
where CategoryID=4;

update CategoryTable
set CategoryName='Cleaning', CategoryDescription='All Cleaning Products'
where CategoryID=5;

select * from dbo.CategoryTable;

