delete from dbo.CategoryTable
where CategoryId=1;
delete from dbo.CategoryTable
where CategoryId=2;

