CREATE TABLE ProductTable (
    ProductId int ,
    column2 datatype,
    column3 datatype,
);