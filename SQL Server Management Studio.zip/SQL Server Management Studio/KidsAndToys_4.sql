/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Id]
      ,[First Name]
      ,[Last Name]
      ,[Birth Date]
  FROM [KidsToys].[dbo].[Kids]