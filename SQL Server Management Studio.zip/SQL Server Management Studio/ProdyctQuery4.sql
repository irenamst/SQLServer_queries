Insert Into dbo.ProductTable
values (1,'Beef',50,120,'Meat')