/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [FirstName]
      ,[LastName]
      ,[Age]
  FROM [Customer].[dbo].[Customer]