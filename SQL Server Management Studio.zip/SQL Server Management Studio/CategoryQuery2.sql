UPDATE dbo.CategoryTable
SET CategoryName = 'Beverage', CategoryDescription='All KINDS OF DRINGS'
WHERE CategoryId = 1;