Insert Into dbo.ProductTable
Values (1,'dddd',100,10,'Beverage')