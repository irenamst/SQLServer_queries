/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [ProductId]
      ,[ProductName]
      ,[ProductQuantity]
      ,[ProductPrice]
      ,[ProductCategory]
  FROM [SuperMarketDataBase].[dbo].[ProductTable]