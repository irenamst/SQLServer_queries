Delete From dbo.ProductTable
where ProductId=1;