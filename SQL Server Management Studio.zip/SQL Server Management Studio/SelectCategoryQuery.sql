/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [CategoryId]
      ,[CategoryName]
      ,[CategoryDescription]
  FROM [SuperMarketDataBase].[dbo].[CategoryTable]