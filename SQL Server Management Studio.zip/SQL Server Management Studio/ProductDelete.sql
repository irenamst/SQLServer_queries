Delete FROM dbo.ProductTable
where [ProductID]=1 
AND [ProductName]='Dish Washes' 
AND [ProductQuantity]='10' 
AND [ProductPrice]='3' 
AND [ProductCategory]='Cleaning';

Select * From dbo.