use SuperMarketDataBase

delete from BuyerListTable

Insert Into BuyerListTable
Values (1,'Ivan',12200,'2022-02-15')
Insert Into BuyerListTable
Values (2,'Hristo',16700,'2022-02-16')
Insert Into BuyerListTable
Values (3,'Vlady',22200,'2022-02-17')
Insert Into BuyerListTable
Values (4,'Todor',16500,'2022-02-18')
Insert Into BuyerListTable
Values (5,'Boby',13200,'2022-02-19')
select * from BuyerListTable