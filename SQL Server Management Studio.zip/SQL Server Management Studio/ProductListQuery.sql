use SuperMarketDataBase

delete from dbo.ProductListTable

Insert Into dbo.ProductListTable
Values (1,'Beef','Meat',120)

Insert Into dbo.ProductListTable
Values(2,'Milk','Dairy',100)

Insert Into dbo.ProductListTable
Values (3,'Graipfruit','Produce',130)

Insert Into dbo.ProductListTable
Values (4,'Orange Juice','Beverage',150)

Insert Into dbo.ProductListTable
Values (5,'Tomatoe','Vegetables',120)