USE [KidsToys]
GO

/****** Object:  Table [dbo].[Toys]    Script Date: 9.3.2022 �. 10:47:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Kids](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[First Name] [int] NULL,
	[Last Name] [varchar](100) NULL,
	[Birth Date] [date] NULL
) ON [PRIMARY]
GO


