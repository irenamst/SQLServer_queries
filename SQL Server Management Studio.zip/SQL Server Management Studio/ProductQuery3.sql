Insert into dbo.ProductTable
Values (1,'dddd',100,20,'Beverage')