/****** Script for SelectTopNRows command from SSMS  ******/
update SellingProductTable
set SellingProductQuantity=50
where SellingProductId=5

update SellingProductTable
set SellingProductCategory='Vegetables'
where SellingProductId=5;

SELECT TOP (1000) [SellingProductId]
      ,[SellingProductName]
      ,[SellingProductPrice]
      ,[SellingProductQuantity]
      ,[SellingProductCategory]
  FROM [SuperMarketDataBase].[dbo].[SellingProductTable]