Select * From dbo.SellerTable
