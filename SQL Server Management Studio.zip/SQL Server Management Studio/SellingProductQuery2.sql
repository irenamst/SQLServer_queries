Insert Into SellingProductList_Table
Values (1,'Milk','Dairy',100)