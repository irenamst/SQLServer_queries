use KidsToys
Select [First Name],[Last Name],[Birth Date]
from Kids
where  [Birth Date]='2008-11-11'