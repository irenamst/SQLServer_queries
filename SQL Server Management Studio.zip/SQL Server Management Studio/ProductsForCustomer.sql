create table Products
(
	id int primary key identity(1,1),
	ProductName varchar(50)
);
select * from Products;
insert into Products
(ProductName) values('Baseball');
insert into Products
(ProductName) values('Batmiton');
alter table Products
add Price float;
select* from Products
insert into Products(ProductName,Price)
values('Baseball',5.95);
insert into Products(ProductName,Price)
values('Bitminton',195.99);

select * from Products;

delete Products;
drop table Products;
create table Products
(
	id int primary key identity(1,1),
	ProductName varchar(50),
	Price float
);
insert into Products(ProductName,Price)
values('Baseball',5.95);
insert into Products(ProductName,Price)
values('Bitminton',195.99);
select * from Products;

drop table Orders
create table Orders
(
	OrderId int primary key identity(1,1),
	OrderDate Datetime,
	CustomerID int,
	ProductID int
);

select * from Orders;
select * from Products;
select * from Customer;

insert into Orders(OrderDate,CustomerID,ProductID)
values(GetDate(),2,2);
insert into Orders(OrderDate,CustomerID,ProductID)
values(GetDate(),1,2);
insert into Orders(OrderDate,CustomerID,ProductID)
values(GetDate(),2,1);
insert into Orders(OrderDate,CustomerID,ProductID)
values(GetDate(),1,1);
insert into Orders(OrderDate,CustomerID,ProductID)
values(GetDate(),3,1);
insert into Orders(OrderDate,CustomerID,ProductID)
values(GetDate(),3,2);

select * from Orders;
select * from Products;
select * from Customer;

insert into Orders(OrderDate,CustomerID,ProductID)
values(GetDate(),4,2);

drop table Orders;

alter table Orders
add foreign key (CustomerID) references Customer(Id)

create table Orders
(
	OrderId int primary key identity(1,1),
	OrderDate Datetime,
	CustomerID int,
	ProductID int
);

delete Orders

select * from dbo.Customer

alter table orders
add foreign key (CustomerId) references Customer(Id)

alter table orders
add foreign key (ProductId) references Products(Id)

select * from Orders
select * from Products
select * from Customer


select * 
from Orders
inner join Products on Orders.ProductID=Products.id

select * from Orders as o
inner join Products as p on o.ProductID=p.id

select * 
from Orders o
inner join Products p  on o.ProductID=p.id

select o.* 
from Orders o
inner join Products p on o.ProductID=p.id

select o.*,p.* 
from Orders o
inner join Products p on o.ProductID=p.id

select o.*, p.*,c.* from 
Orders o
inner join Products p on o.ProductID=p.id
inner join Customer c on o.CustomerID=c.id

select o.OrderDate, p.ProductName, p.Price,c.*
from Orders o
inner join Products p on o.ProductID=p.id
inner join Customer c on o.CustomerID=c.id

select p.Price
from Orders o
inner join Products p on o.ProductID=p.id
inner join Customer c on o.CustomerID=c.id

select sum(p.Price)
from Orders o
inner join Products p on o.ProductID=p.id
inner join Customer c on o.CustomerID=c.id

select sum(p.Price) as Total
from Orders o
inner join Products p on o.ProductID=p.id
inner join Customer c on o.CustomerID=c.id

select c.LastName, sum(p.Price) Total
from Orders o
inner join Products p on o.ProductID=p.id
inner join Customer c on o.CustomerID=c.id
group by c.LastName

select c.LastName, p.ProductName, sum(p.Price) Total
from Orders o
inner join Products p on o.ProductID=p.id
inner join Customer c on o.CustomerID=c.id
group by c.LastName, p.ProductName

select c.City, sum(p.Price) Total
from Orders o
inner join Products p on o.ProductID=p.id
inner join Customer c on o.CustomerID=c.id
group by c.City

select c.City, sum(p.Price), AVG(p.price) Total
from Orders o
inner join Products p on o.ProductID=p.id
inner join Customer c on o.CustomerID=c.id
group by c.City

