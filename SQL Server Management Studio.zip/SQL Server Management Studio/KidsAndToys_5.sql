USE KidsToys

DROP TABLE Kids
DROP TABLE Toys

CREATE TABLE Kids (
Id  INT IDENTITY (1,1)
,[First Name] VARCHAR(100)
,[Last Name]  VARCHAR(100)
,[Birth Date]  DATETIME
)

CREATE TABLE Toys (
Id  INT IDENTITY (1,1)
,[Kid Id]  INT
,Name VARCHAR(100)
,Colour  VARCHAR(100)
)

SELECT * FROM dbo.Kids
SELECT * FROM dbo.Toys

DELETE FROM Kids
DELETE FROM Toys

INSERT INTO Kids ([First Name],[Last Name],[Birth Date])
VALUES
('Sam','Small',DATEADD(Month,- floor(rand() * 120),GetDate()))
,('Annie',null,'20180527')
,('Dave','Drei','20140325')
,('Ivan','Ivanov','20150517')
,('Brenda','Simon','20160315')
,('Samantha','Fox','20190715')
,('Diana','Ros','20160918')
,('Michael','Buble','20190410')
,('Bilbo','Baggins','20200125')
,('Rox','Mirers','20130411')
,('Frodo','Baggins','20150313')
,('Riana','Wober','20161115')
,('Marta',null,'20121230')

SELECT * FROM dbo.Kids
SELECT * FROM dbo.Toys

INSERT INTO Toys ([Kid Id],Name,Colour)
VALUES
('1','car','blue')
,('1','ball','red')
,('1','doll','blue')
,('2','truck','green')
,('2','car','red')
,('2','ball','green')
,('2','doll','blue')
,('3','car','green')
,('4','doll','red')
,('4','ball','blue')
,('5','ball','green')
,('6','truck','blue')
,('6','truck','red')
,('7','car','green')
,('2','car','green')
,('1','ball','blue')
,('1','car','red')

SELECT * FROM dbo.Kids
SELECT * FROM dbo.Toys

/*
Select full name (in one cell), Birth Date of all kids 3 years old and above
expected column list: Full Name( ex. "Sam Small"), Birth Date (ex. "2021-08-18" )
*/

SELECT CONCAT([First Name],' ',[Last Name]) AS [Full Name] ,
	DATEFROMPARTS(YEAR([Birth Date]), MONTH([Birth Date]), Day([Birth Date])) AS [Birth Date]
FROM Kids
WHERE DateDiff(year,[Birth Date],CAST(GETDATE() AS DATE))>=3

/*
Select all kids who have more than 2 blue toys
expected column list: Full Name( ex. "Sam Small"), Number of Blue Toys
*/

SELECT CONCAT(k.[First Name],' ',k.[Last Name]) AS [Full Name], COUNT(t.Colour) AS [Number of Blue Toys]
FROM Kids AS k, Toys AS t
WHERE k.Id=t.[Kid Id] AND t.Colour = 'blue' 
GROUP BY k.[First Name], k.[Last Name]
HAVING COUNT(t.Colour)>=2
ORDER BY COUNT(t.Colour) DESC;

/*
Select all kids under 5 years of age who have more than 1 toy
expected column list: Full Name( ex. "Sam Small"), Birth Date  (ex. "2021-08-18" ), Number of Toys
*/

SELECT CONCAT(k.[First Name],' ',k.[Last Name]) AS [Full Name] ,
	DATEFROMPARTS(YEAR(k.[Birth Date]), MONTH(k.[Birth Date]), Day(k.[Birth Date])) AS [Birth Date] , 
	COUNT(t.Id) AS [Number Of Toys] 
FROM Kids AS k,Toys AS t
WHERE k.Id=t.[Kid Id] AND DateDiff(year,[Birth Date],CAST(GETDATE() AS DATE))<=5
GROUP BY k.[First Name],k.[Last Name],k.[Birth Date]
HAVING COUNT(t.Id)>=1
ORDER BY COUNT(t.Id) DESC;


/*
Select all kids with no toys at all
expected column list: Full Name( ex. "Sam Small")
*/
SELECT CONCAT(k.[First Name],' ',k.[Last Name]) AS [Full Name]
FROM Kids k
FULL OUTER JOIN Toys t ON k.Id = t.[Kid Id]
Group by k.[First Name],k.[Last Name]
Having COUNT(t.Id)=0

/*
Select all kids having birthday in April
expected column list: Full Name( ex. "Sam Small"), Birth Date  (ex. "2021-08-18" )
*/

SELECT CONCAT(k.[First Name],' ',k.[Last Name]) AS [Full Name], 
	DATEFROMPARTS(YEAR(k.[Birth Date]), MONTH(k.[Birth Date]), Day(k.[Birth Date])) AS [Birth Date] 
FROM Kids k
WHERE MONTH(k.[Birth Date])=4

/*
Select all the kids with the highest number of toys (if more than one show all of them)
expected column list: Kid id, Full Name( ex. "Sam Small"), Number of toys
*/

SELECT k.id,CONCAT(k.[First Name],' ',k.[Last Name]) AS [Full Name], COUNT(t.Id) AS [Number of toys]
FROM Kids k, Toys t
WHERE k.Id=t.[Kid Id]
GROUP BY k.Id,k.[First Name],k.[Last Name]
HAVING COUNT(t.Id)=5
ORDER BY [Number of toys] DESC




/*
Select all kids ordered by toy count if two kids has same number of toys their names should be in one cell separated by comma
we need just an idea how this could be achieved (don't spent much time on this will be discussed)
*/

SELECT DISTINCT COUNT(t.Id) As [Number of toys]
FROM Kids k, Toys t
where k.id=t.[Kid Id]
Group By k.Id

SELECT COUNT(*) As [Number of toys]
FROM (SELECT DISTINCT COUNT(t.Id) As [Number of toys]
FROM  Kids k, Toys t
Where k.id = t.[Kid Id]
Group by k.id
)AS [Number of toys]

SELECT CONCAT([First Name],' ',[Last Name]) AS [Full Name]
FROM Kids k


SELECT CONCAT(k1.[First Name],' ',k1.[Last Name]) AS [Full Name], CONCAT(k2.[First Name],' ', k2.[Last Name]) AS [Full Name]
From Kids k1, Kids k2
Where k1.Id <> k2.Id

SELECT CONCAT(k1.[First Name],' ',k1.[Last Name]) AS [Full Name], CONCAT(k2.[First Name],' ', k2.[Last Name]) AS [Full Name], COUNT(t.id) AS [Number of Toys]
From Kids k1, Kids k2,Toys t
Where k1.Id <> k2.Id
GROUP BY k1.[First Name],k1.[Last Name],k2.[First Name],k2.[Last Name]

SELECT CONCAT(k1.[First Name],' ',k1.[Last Name]) AS [Full Name], CONCAT(k2.[First Name],' ', k2.[Last Name]) AS [Full Name], COUNT(t.id) AS [Number of Toys]
From Kids k1, Kids k2,Toys t
Where k1.Id <> k2.Id AND t.[Kid Id]=k1.Id
GROUP BY k1.[First Name],k1.[Last Name],k2.[First Name],k2.[Last Name]
order by Count(t.Id) DESC

SELECT CONCAT(k1.[First Name],' ',k1.[Last Name],', ',k2.[First Name],' ', k2.[Last Name]) AS [Full Name], COUNT(t.id) AS [Number of Toys]
From Kids k1, Kids k2,Toys t
Where k1.Id <> k2.Id AND t.[Kid Id]=k1.Id
GROUP BY k1.[First Name],k1.[Last Name],k2.[First Name],k2.[Last Name]
order by Count(t.Id) DESC







SELECT CONCAT(k.[First Name],' ',k.[Last Name]) AS [Full Name], COUNT(t.Id) AS [Number of toys]
FROM kids k, toys t
WHERE k.id=t.[kid id]
GROUP BY k.Id,k.[First Name],k.[Last Name]
HAVING COUNT(t.Id)=5 
ORDER BY [Number of toys] DESC

SELECT CONCAT(k.[First Name],' ',k.[Last Name]) AS [Full Name], COUNT(t.Id) AS [Number of toys]
FROM kids k, toys t
WHERE k.id=t.[kid id]
GROUP BY k.Id,k.[First Name],k.[Last Name]
HAVING COUNT(t.Id)=2
ORDER BY [Number of toys] DESC

SELECT CONCAT(k.[First Name],' ',k.[Last Name]) AS [Full Name], COUNT(t.Id) AS [Number of toys]
FROM kids k, toys t
WHERE k.id=t.[kid id]
GROUP BY k.Id,k.[First Name],k.[Last Name]
HAVING COUNT(t.Id)=1
ORDER BY [Number of toys] DESC
