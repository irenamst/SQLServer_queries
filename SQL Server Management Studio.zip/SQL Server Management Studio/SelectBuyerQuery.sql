/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [BuyerId]
      ,[BuyerName]
      ,[BuyerAmount]
      ,[BuyingDate]
  FROM [SuperMarketDataBase].[dbo].[BuyerListTable]