/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [ListId]
      ,[ListName]
      ,[ListCategory]
      ,[ListPrice]
  FROM [SuperMarketDataBase].[dbo].[ProductListTable]