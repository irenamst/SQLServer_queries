Insert Into dbo.SellerTable
Values (1,'John',33,'089 898 9898','johnpass');